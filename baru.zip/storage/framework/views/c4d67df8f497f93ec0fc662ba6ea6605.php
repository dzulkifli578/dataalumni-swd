<footer class="bg-gray-800 text-white p-4 text-center">
    &copy; 2024 SMK Swadhipa 2 Natar. All rights reserved.
</footer>
<?php /**PATH D:\Dzulkifli\Laravel\baru\resources\views/akun/footer.blade.php ENDPATH**/ ?>